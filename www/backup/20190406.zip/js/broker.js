//Caller




function admloadsportslist(redirectpage){

     //show loading 

     //
      app.request.post($base_url+'gameeventstype/read_paging.php'+$base_param, 
        ''
        ,function (data){
            GetData(data,redirectpage);
            },'json');
      
      app.panel.close();
    
  }

  //Async Response
  function GetData(data,redirectpage) {
    app.brokerdata=data.records;
    console.log(app.brokerdata);

    //remove loading page
    app.views.main.router.navigate(redirectpage);


  }