//Read config file//Dev

$base_url='http://127.0.0.1/edsa-gb-api/';
$base_param='?';
